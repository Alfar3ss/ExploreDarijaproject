/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // `appDir` is enabled by default in newer Next.js versions.
  // Remove experimental config to avoid invalid-next-config errors.
}

module.exports = nextConfig
