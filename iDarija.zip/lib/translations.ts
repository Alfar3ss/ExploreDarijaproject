const translations = {
  en: {
    site: { name: 'ExploreDarija', slogan: 'Discover Moroccan Darija with ease', slogan_short: 'Discover Moroccan Darija' },
    nav: { home: 'Home', blog: 'Blog', dictionary: 'Dictionary', pricing: 'Pricing', translator: 'Translator', login: 'Login' },
    footer: { terms: 'Terms', privacy: 'Privacy', contact: 'Contact', title_site: 'Site', title_legal: 'Legal', description: 'Learn everyday Moroccan Darija with example phrases, a searchable dictionary, and a helpful translator.' },
    home: {
      hero_title: 'Learn Darija',
      hero_sub: 'A modern, friendly platform to explore Moroccan Arabic through lessons, expressions, audio, and real daily conversation.',
      cta_start: 'Start Learning',
      cta_dictionary: 'Open Dictionary',
      features_title: "What You'll Discover",
      features_daily: 'Daily Expressions',
      features_dictionary: 'Dictionary',
      features_audio: 'Audio Lessons',
      quote: "Darija is not just a language — it's a rhythm, a feeling, a piece of Morocco you carry with you.",
    },
    blog: {
      title: 'Blog',
      subtitle: 'Welcome to our Darija Blog — your place to explore Morocco through language, culture, and daily expressions.',
      search_placeholder: 'Search posts, tips, or places',
      all: 'All',
      featured: 'Featured',
      recent_posts: 'Recent posts',
      not_found: 'Post not found',
      back_to_blog: 'Back to blog',
      back: 'Back',
      comments_title: 'Comments',
      comments_sub: 'Share your thoughts — please be respectful. You must be logged in to comment.',
      commenting_as: 'Commenting as',
      comment_placeholder: 'Write a helpful comment...',
      post_comment: 'Post comment',
      clear: 'Clear',
      not_logged_in: 'You are not logged in.',
      to_comment: 'to comment.',
      no_comments: 'No comments yet — be the first to comment.'
    },
    dictionary: {
      title: 'Darija Dictionary',
      subtitle: 'Search thousands of real Moroccan Arabic words, expressions, slang terms, verbs, and everyday phrases.',
      search_dar_en: 'Search Darija → English',
      search_en_dar: 'Search English → Darija',
      search_fr_dar: 'Search French → Darija',
      search_es_dar: 'Search Spanish → Darija',
      search_it_dar: 'Search Italian → Darija',
      search_button: 'Search',
      no_results: 'No results — try a different word or remove filters.',
      favorites_empty: 'No saved words yet. Click the star to save.',
      add_to_favorites: 'Add to favorites',
      remove_from_favorites: 'Remove from favorites',
      add_short: '☆',
      remove_short: '★',
      meaning_label: 'Meaning:',
      examples_title: 'Examples',
      notes_title: 'Notes about usage',
      notes_text: 'Moroccans often use'
    },
    translator: {
      title: 'Darija Translator',
      description: 'Use our fast and accurate translator to convert English, French, Spanish, or Italian into Moroccan Darija.',
      from: 'From',
      to: 'To',
      enter_text: 'Enter text to translate',
      translate: 'Translate',
      no_translation: 'No translation yet. Click Translate.',
      save: 'Save',
      play: 'Play',
      sample_where: 'Where are you?',
      sample_howmuch: 'How much is this?',
      sample_hello: 'Hello'
    },
    pricing: {
      title: 'Choose Your Plan',
      subtitle: 'ExploreDarija offers flexible learning plans for beginners, travelers, and advanced learners. Choose the plan that fits your goals and learning style. No hidden fees.',
      billing: 'Billing',
      monthly: 'Monthly',
      yearly: 'Yearly',
      free: 'Free',
      standard: 'Standard',
      premium: 'Premium+',
      get_started: 'Get Started',
      choose_plan: 'Choose Plan and Begin',
      compare_title: 'Compare Plans',
      faq_title: 'Frequently Asked Questions'
    },
    login: {
      title: 'Login',
      subtitle: 'Sign in to continue your lessons and progress.',
      email: 'Email',
      password: 'Password',
      sign_in: 'Sign In'
    },
    terms: {
      title: 'Terms of Service',
      placeholder: 'These are placeholder terms for ExploreDarija. Replace with your actual terms.'
    },
    privacy: {
      title: 'Privacy Policy',
      placeholder: 'This is a placeholder privacy policy. Update with your real privacy practices.'
    },
    contact: {
      title: 'Contact',
      placeholder: 'Have questions or feedback? Drop us a message.' ,
      name: 'Name',
      email: 'Email',
      message: 'Message',
      send: 'Send'
    }
  },
  fr: {
    site: { name: 'ExploreDarija', slogan: 'Découvrez le Darija marocain facilement', slogan_short: 'Découvrez le Darija marocain' },
    nav: { home: 'Accueil', blog: 'Blog', dictionary: 'Dictionnaire', pricing: 'Tarifs', translator: 'Traducteur', login: 'Connexion' },
    footer: { terms: 'Conditions', privacy: 'Confidentialité', contact: 'Contact', title_site: 'Site', title_legal: 'Légal', description: 'Apprenez le Darija marocain avec des phrases d’exemple, un dictionnaire consultable et un traducteur utile.' },
    home: {
      hero_title: 'Apprenez le Darija',
      hero_sub: 'Une plateforme moderne et conviviale pour explorer l’arabe marocain à travers des leçons, des expressions, de l’audio et des conversations quotidiennes.',
      cta_start: 'Commencer',
      cta_dictionary: 'Ouvrir le dictionnaire',
      features_title: 'Ce que vous découvrirez',
      features_daily: 'Expressions quotidiennes',
      features_dictionary: 'Dictionnaire',
      features_audio: 'Leçons audio',
      quote: "Le Darija n'est pas seulement une langue — c'est un rythme, un sentiment, un morceau du Maroc que vous emportez avec vous."
    },
    blog: {
      title: 'Blog',
      subtitle: 'Bienvenue sur notre blog Darija — découvrez le Maroc à travers la langue, la culture et les expressions quotidiennes.',
      search_placeholder: 'Rechercher des articles, astuces ou lieux',
      all: 'Tout',
      featured: 'En vedette',
      recent_posts: 'Articles récents'
      ,not_found: 'Article non trouvé',
      back_to_blog: 'Retour au blog',
      back: 'Retour',
      comments_title: 'Commentaires',
      comments_sub: 'Partagez vos impressions — soyez respectueux. Vous devez être connecté pour commenter.',
      commenting_as: 'Vous commentez en tant que',
      comment_placeholder: 'Écrivez un commentaire utile...',
      post_comment: 'Publier le commentaire',
      clear: 'Effacer',
      not_logged_in: 'Vous n’êtes pas connecté.',
      to_comment: 'pour commenter.',
      no_comments: 'Aucun commentaire pour le moment — soyez le premier.'
    },
    dictionary: {
      title: 'Dictionnaire Darija',
      subtitle: 'Recherchez des mots et expressions marocains avec définitions, exemples et prononciation.',
      search_dar_en: 'Rechercher Darija → Anglais',
      search_en_dar: 'Rechercher Anglais → Darija',
      search_fr_dar: 'Rechercher Français → Darija',
      search_es_dar: 'Rechercher Espagnol → Darija',
      search_it_dar: 'Rechercher Italien → Darija',
      search_button: 'Rechercher',
      no_results: 'Aucun résultat — essayez un autre mot ou enlevez les filtres.',
      favorites_empty: 'Aucun mot sauvegardé. Cliquez sur l’étoile pour sauvegarder.'
      ,add_to_favorites: 'Ajouter aux favoris',
      remove_from_favorites: 'Retirer des favoris',
      add_short: '☆',
      remove_short: '★',
      meaning_label: 'Sens :',
      examples_title: 'Exemples',
      notes_title: 'Remarques d’utilisation',
      notes_text: 'Les Marocains utilisent souvent'
    },
    translator: {
      title: 'Traducteur Darija',
      description: 'Utilisez notre traducteur rapide pour convertir l’anglais, le français, l’espagnol ou l’italien en Darija marocain.',
      from: 'De',
      to: 'Vers',
      enter_text: 'Entrez le texte à traduire',
      translate: 'Traduire',
      no_translation: 'Pas de traduction pour le moment. Cliquez sur Traduire.',
      save: 'Sauvegarder',
      play: 'Écouter',
      sample_where: 'Où es-tu ?',
      sample_howmuch: 'Combien ça coûte ?',
      sample_hello: 'Bonjour'
    },
    pricing: {
      title: 'Choisissez votre offre',
      subtitle: 'ExploreDarija propose des plans flexibles pour débutants, voyageurs et apprenants avancés. Choisissez le plan qui correspond à vos objectifs.',
      billing: 'Facturation',
      monthly: 'Mensuel',
      yearly: 'Annuel',
      free: 'Gratuit',
      standard: 'Standard',
      premium: 'Premium+',
      get_started: 'Commencer',
      choose_plan: 'Choisir le plan et commencer',
      compare_title: 'Comparer les plans',
      faq_title: 'Questions fréquentes'
    },
    login: {
      title: 'Connexion',
      subtitle: 'Connectez-vous pour poursuivre vos leçons et votre progression.',
      email: 'Email',
      password: 'Mot de passe',
      sign_in: 'Se connecter'
    },
    terms: {
      title: 'Conditions d’utilisation',
      placeholder: 'Ce sont des conditions temporaires pour ExploreDarija. Remplacez-les par vos conditions réelles.'
    },
    privacy: {
      title: 'Confidentialité',
      placeholder: 'Ceci est une politique de confidentialité temporaire. Mettez à jour selon vos pratiques.'
    },
    contact: {
      title: 'Contact',
      placeholder: 'Questions ou retours ? Envoyez-nous un message.',
      name: 'Nom',
      email: 'Email',
      message: 'Message',
      send: 'Envoyer'
    }
  },
  es: {
    site: { name: 'ExploreDarija', slogan: 'Descubre el Darija marroquí fácilmente', slogan_short: 'Descubre el Darija marroquí' },
    nav: { home: 'Inicio', blog: 'Blog', dictionary: 'Diccionario', pricing: 'Precios', translator: 'Traductor', login: 'Iniciar sesión' },
    footer: { terms: 'Términos', privacy: 'Privacidad', contact: 'Contacto', title_site: 'Sitio', title_legal: 'Legal', description: 'Aprende Darija marroquí con frases de ejemplo, un diccionario buscable y un traductor útil.' },
    home: {
      hero_title: 'Aprende Darija',
      hero_sub: 'Una plataforma moderna y amigable para explorar el árabe marroquí con lecciones, expresiones, audio y conversaciones reales.',
      cta_start: 'Comenzar',
      cta_dictionary: 'Abrir diccionario',
      features_title: 'Qué descubrirás',
      features_daily: 'Expresiones diarias',
      features_dictionary: 'Diccionario',
      features_audio: 'Lecciones de audio',
      quote: 'El Darija no es solo un idioma — es un ritmo, un sentimiento, un pedazo de Marruecos que llevas contigo.'
    },
    blog: {
      title: 'Blog',
      subtitle: 'Bienvenido a nuestro blog Darija — explora Marruecos a través del lenguaje, la cultura y las expresiones diarias.',
      search_placeholder: 'Buscar publicaciones, consejos o lugares',
      all: 'Todo',
      featured: 'Destacado',
      recent_posts: 'Publicaciones recientes'
      ,not_found: 'Publicación no encontrada',
      back_to_blog: 'Volver al blog',
      back: 'Volver',
      comments_title: 'Comentarios',
      comments_sub: 'Comparte tus pensamientos — por favor sé respetuoso. Debes iniciar sesión para comentar.',
      commenting_as: 'Comentando como',
      comment_placeholder: 'Escribe un comentario útil...',
      post_comment: 'Publicar comentario',
      clear: 'Borrar',
      not_logged_in: 'No has iniciado sesión.',
      to_comment: 'para comentar.',
      no_comments: 'No hay comentarios todavía — sé el primero.'
    },
    dictionary: {
      title: 'Diccionario Darija',
      subtitle: 'Busca miles de palabras y expresiones marroquíes con significados, ejemplos y pronunciación.',
      search_dar_en: 'Buscar Darija → Inglés',
      search_en_dar: 'Buscar Inglés → Darija',
      search_fr_dar: 'Buscar Francés → Darija',
      search_es_dar: 'Buscar Español → Darija',
      search_it_dar: 'Buscar Italiano → Darija',
      search_button: 'Buscar',
      no_results: 'Sin resultados — prueba otra palabra o elimina filtros.',
      favorites_empty: 'No hay palabras guardadas. Haz clic en la estrella para guardar.'
      ,add_to_favorites: 'Agregar a favoritos',
      remove_from_favorites: 'Eliminar de favoritos',
      add_short: '☆',
      remove_short: '★',
      meaning_label: 'Significado:',
      examples_title: 'Ejemplos',
      notes_title: 'Notas sobre uso',
      notes_text: 'Los marroquíes suelen usar'
    },
    translator: {
      title: 'Traductor Darija',
      description: 'Usa nuestro traductor rápido para convertir inglés, francés, español o italiano a Darija marroquí.',
      from: 'De',
      to: 'A',
      enter_text: 'Ingrese texto para traducir',
      translate: 'Traducir',
      no_translation: 'Sin traducción aún. Haz clic en Traducir.',
      save: 'Guardar',
      play: 'Reproducir',
      sample_where: '¿Dónde estás?',
      sample_howmuch: '¿Cuánto cuesta esto?',
      sample_hello: 'Hola'
    },
    pricing: {
      title: 'Elige tu plan',
      subtitle: 'ExploreDarija ofrece planes flexibles para principiantes, viajeros y estudiantes avanzados. Elige el que se adapte a tus objetivos.',
      billing: 'Facturación',
      monthly: 'Mensual',
      yearly: 'Anual',
      free: 'Gratis',
      standard: 'Standard',
      premium: 'Premium+',
      get_started: 'Comenzar',
      choose_plan: 'Elegir plan y comenzar',
      compare_title: 'Comparar planes',
      faq_title: 'Preguntas frecuentes'
    },
    login: {
      title: 'Iniciar sesión',
      subtitle: 'Inicia sesión para continuar tus lecciones y progreso.',
      email: 'Email',
      password: 'Contraseña',
      sign_in: 'Iniciar sesión'
    },
    terms: {
      title: 'Términos de servicio',
      placeholder: 'Estos son términos temporales para ExploreDarija. Reemplázalos por tus términos reales.'
    },
    privacy: {
      title: 'Privacidad',
      placeholder: 'Esta es una política de privacidad temporal. Actualízala según tus prácticas.'
    },
    contact: {
      title: 'Contacto',
      placeholder: '¿Preguntas o comentarios? Envíanos un mensaje.',
      name: 'Nombre',
      email: 'Email',
      message: 'Mensaje',
      send: 'Enviar'
    }
  },
  it: {
    site: { name: 'ExploreDarija', slogan: "Scopri il Darija marocchino con facilità", slogan_short: 'Scopri il Darija marocchino' },
    nav: { home: 'Home', blog: 'Blog', dictionary: 'Dizionario', pricing: 'Prezzi', translator: 'Traduttore', login: 'Accedi' },
    footer: { terms: 'Termini', privacy: 'Privacy', contact: 'Contatto', title_site: 'Sito', title_legal: 'Legale', description: 'Impara il Darija marocchino con frasi di esempio, un dizionario consultabile e un traduttore utile.' },
    home: {
      hero_title: 'Impara il Darija',
      hero_sub: "Una piattaforma moderna e amichevole per esplorare l'arabo marocchino attraverso lezioni, espressioni, audio e conversazioni quotidiane.",
      cta_start: 'Inizia a imparare',
      cta_dictionary: 'Apri il dizionario',
      features_title: 'Cosa scoprirai',
      features_daily: 'Espressioni quotidiane',
      features_dictionary: 'Dizionario',
      features_audio: 'Lezioni audio',
      quote: "Il Darija non è solo una lingua — è un ritmo, un sentimento, un pezzo del Marocco che porti con te."
    },
    blog: {
      title: 'Blog',
      subtitle: 'Benvenuto nel nostro blog Darija — esplora il Marocco attraverso lingua, cultura ed espressioni quotidiane.',
      search_placeholder: 'Cerca post, suggerimenti o luoghi',
      all: 'Tutti',
      featured: 'In evidenza',
      recent_posts: 'Post recenti'
      ,not_found: 'Articolo non trovato',
      back_to_blog: 'Torna al blog',
      back: 'Indietro',
      comments_title: 'Commenti',
      comments_sub: 'Condividi i tuoi pensieri — per favore sii rispettoso. Devi essere connesso per commentare.',
      commenting_as: 'Commenti come',
      comment_placeholder: 'Scrivi un commento utile...',
      post_comment: 'Pubblica commento',
      clear: 'Cancella',
      not_logged_in: 'Non hai effettuato l’accesso.',
      to_comment: 'per commentare.',
      no_comments: 'Ancora nessun commento — sii il primo.'
    },
    dictionary: {
      title: 'Dizionario Darija',
      subtitle: 'Cerca migliaia di parole ed espressioni marocchine con significati, esempi e pronuncia.',
      search_dar_en: 'Cerca Darija → Inglese',
      search_en_dar: 'Cerca Inglese → Darija',
      search_fr_dar: 'Cerca Francese → Darija',
      search_es_dar: 'Cerca Spagnolo → Darija',
      search_it_dar: 'Cerca Italiano → Darija',
      search_button: 'Cerca',
      no_results: 'Nessun risultato — prova con un’altra parola o rimuovi i filtri.',
      favorites_empty: 'Nessuna parola salvata. Clicca sulla stella per salvare.'
      ,add_to_favorites: 'Aggiungi ai preferiti',
      remove_from_favorites: 'Rimuovi dai preferiti',
      add_short: '☆',
      remove_short: '★',
      meaning_label: 'Significato:',
      examples_title: 'Esempi',
      notes_title: 'Note sull’uso',
      notes_text: 'I marocchini spesso usano'
    },
    translator: {
      title: 'Traduttore Darija',
      description: 'Usa il nostro traduttore veloce per convertire inglese, francese, spagnolo o italiano in Darija marocchino.',
      from: 'Da',
      to: 'A',
      enter_text: 'Inserisci il testo da tradurre',
      translate: 'Traduci',
      no_translation: 'Nessuna traduzione ancora. Clicca Traduci.',
      save: 'Salva',
      play: 'Ascolta',
      sample_where: 'Dove sei?',
      sample_howmuch: 'Quanto costa questo?',
      sample_hello: 'Ciao'
    },
    pricing: {
      title: 'Scegli il tuo piano',
      subtitle: 'ExploreDarija offre piani flessibili per principianti, viaggiatori e studenti avanzati. Scegli il piano che si adatta ai tuoi obiettivi.',
      billing: 'Fatturazione',
      monthly: 'Mensile',
      yearly: 'Annua',
      free: 'Gratuito',
      standard: 'Standard',
      premium: 'Premium+',
      get_started: 'Inizia',
      choose_plan: 'Scegli il piano e inizia',
      compare_title: 'Confronta i piani',
      faq_title: 'Domande frequenti'
    },
    login: {
      title: 'Accesso',
      subtitle: 'Accedi per continuare le tue lezioni e i tuoi progressi.',
      email: 'Email',
      password: 'Password',
      sign_in: 'Accedi'
    },
    terms: {
      title: 'Termini di servizio',
      placeholder: 'Questi sono termini segnaposto per ExploreDarija. Sostituiscili con i tuoi termini reali.'
    },
    privacy: {
      title: 'Privacy',
      placeholder: 'Questa è una politica sulla privacy segnaposto. Aggiornala con le tue pratiche.'
    },
    contact: {
      title: 'Contatto',
      placeholder: 'Domande o feedback? Inviaci un messaggio.',
      name: 'Nome',
      email: 'Email',
      message: 'Messaggio',
      send: 'Invia'
    }
  },
  de: {
    site: { name: 'ExploreDarija', slogan: 'Entdecke marokkanisches Darija mit Leichtigkeit', slogan_short: 'Entdecke marokkanisches Darija' },
    nav: { home: 'Start', blog: 'Blog', dictionary: 'Wörterbuch', pricing: 'Preise', translator: 'Übersetzer', login: 'Anmelden' },
    footer: { terms: 'Nutzungsbedingungen', privacy: 'Datenschutz', contact: 'Kontakt', title_site: 'Seite', title_legal: 'Rechtliches', description: 'Lerne alltägliches marokkanisches Darija mit Beispielsätzen, einem durchsuchbaren Wörterbuch und einem nützlichen Übersetzer.' },
    home: {
      hero_title: 'Lerne Darija',
      hero_sub: 'Eine moderne, freundliche Plattform, um marokkanisches Arabisch durch Lektionen, Ausdrücke, Audio und echte tägliche Gespräche zu erkunden.',
      cta_start: 'Loslegen',
      cta_dictionary: 'Wörterbuch öffnen',
      features_title: 'Was du entdecken wirst',
      features_daily: 'Alltägliche Ausdrücke',
      features_dictionary: 'Wörterbuch',
      features_audio: 'Audio-Lektionen',
      quote: 'Darija ist nicht nur eine Sprache — es ist ein Rhythmus, ein Gefühl, ein Stück Marokko, das du mit dir trägst.'
    },
    blog: {
      title: 'Blog',
      subtitle: 'Willkommen in unserem Darija-Blog — erkunde Marokko durch Sprache, Kultur und tägliche Ausdrücke.',
      search_placeholder: 'Beiträge, Tipps oder Orte suchen',
      all: 'Alle',
      featured: 'Ausgewählt',
      recent_posts: 'Aktuelle Beiträge'
      ,not_found: 'Beitrag nicht gefunden',
      back_to_blog: 'Zurück zum Blog',
      back: 'Zurück',
      comments_title: 'Kommentare',
      comments_sub: 'Teile deine Gedanken — bitte sei respektvoll. Du musst eingeloggt sein, um zu kommentieren.',
      commenting_as: 'Kommentiere als',
      comment_placeholder: 'Schreibe einen hilfreichen Kommentar...',
      post_comment: 'Kommentar posten',
      clear: 'Löschen',
      not_logged_in: 'Du bist nicht eingeloggt.',
      to_comment: 'um zu kommentieren.',
      no_comments: 'Noch keine Kommentare — sei der Erste.'
    },
    dictionary: {
      title: 'Darija-Wörterbuch',
      subtitle: 'Durchsuche tausende reale marokkanische Wörter und Ausdrücke mit Bedeutungen, Beispielen und Aussprache.',
      search_dar_en: 'Darija → Englisch',
      search_en_dar: 'Englisch → Darija',
      search_fr_dar: 'Französisch → Darija',
      search_es_dar: 'Spanisch → Darija',
      search_it_dar: 'Italienisch → Darija',
      search_button: 'Suchen',
      no_results: 'Keine Ergebnisse — versuche ein anderes Wort oder entferne Filter.',
      favorites_empty: 'Noch keine gespeicherten Wörter. Klicke auf den Stern, um zu speichern.'
      ,add_to_favorites: 'Zu Favoriten hinzufügen',
      remove_from_favorites: 'Von Favoriten entfernen',
      add_short: '☆',
      remove_short: '★',
      meaning_label: 'Bedeutung:',
      examples_title: 'Beispiele',
      notes_title: 'Hinweise zur Verwendung',
      notes_text: 'Marokkaner verwenden oft'
    },
    translator: {
      title: 'Darija-Übersetzer',
      description: 'Verwende unseren schnellen Übersetzer, um Englisch, Französisch, Spanisch oder Italienisch ins marokkanische Darija zu übersetzen.',
      from: 'Von',
      to: 'Nach',
      enter_text: 'Text zum Übersetzen eingeben',
      translate: 'Übersetzen',
      no_translation: 'Noch keine Übersetzung. Klicke auf Übersetzen.',
      save: 'Speichern',
      play: 'Abspielen',
      sample_where: 'Wo bist du?',
      sample_howmuch: 'Wie viel kostet das?',
      sample_hello: 'Hallo'
    },
    pricing: {
      title: 'Wähle deinen Plan',
      subtitle: 'ExploreDarija bietet flexible Lernpläne für Anfänger, Reisende und Fortgeschrittene. Wähle den Plan, der zu deinen Zielen passt.',
      billing: 'Abrechnung',
      monthly: 'Monatlich',
      yearly: 'Jährlich',
      free: 'Kostenlos',
      standard: 'Standard',
      premium: 'Premium+',
      get_started: 'Loslegen',
      choose_plan: 'Plan wählen und beginnen',
      compare_title: 'Pläne vergleichen',
      faq_title: 'Häufig gestellte Fragen'
    },
    login: {
      title: 'Anmelden',
      subtitle: 'Melde dich an, um deine Lektionen und Fortschritte fortzusetzen.',
      email: 'Email',
      password: 'Passwort',
      sign_in: 'Anmelden'
    },
    terms: {
      title: 'Nutzungsbedingungen',
      placeholder: 'Dies sind Platzhalter-Bedingungen für ExploreDarija. Bitte durch echte Bedingungen ersetzen.'
    },
    privacy: {
      title: 'Datenschutz',
      placeholder: 'Dies ist eine Platzhalter-Datenschutzrichtlinie. Aktualisiere sie entsprechend deinen Praktiken.'
    },
    contact: {
      title: 'Kontakt',
      placeholder: 'Fragen oder Feedback? Sende uns eine Nachricht.',
      name: 'Name',
      email: 'Email',
      message: 'Nachricht',
      send: 'Senden'
    }
  },
  nl: {
    site: { name: 'ExploreDarija', slogan: 'Ontdek Marokkaans Darija met gemak', slogan_short: 'Ontdek Marokkaans Darija' },
    nav: { home: 'Start', blog: 'Blog', dictionary: 'Woordenboek', pricing: 'Prijzen', translator: 'Vertaler', login: 'Inloggen' },
    footer: { terms: 'Voorwaarden', privacy: 'Privacy', contact: 'Contact', title_site: 'Site', title_legal: 'Juridisch', description: 'Leer dagelijks Marokkaans Darija met voorbeeldzinnen, een doorzoekbaar woordenboek en een handige vertaler.' },
    home: {
      hero_title: 'Leer Darija',
      hero_sub: 'Een moderne, vriendelijke plek om Marokkaans Arabisch te ontdekken via lessen, uitdrukkingen, audio en dagelijkse gesprekken.',
      cta_start: 'Begin met leren',
      cta_dictionary: 'Open woordenboek',
      features_title: 'Wat je zult ontdekken',
      features_daily: 'Dagelijkse uitdrukkingen',
      features_dictionary: 'Woordenboek',
      features_audio: 'Audio lessen',
      quote: 'Darija is niet alleen een taal — het is een ritme, een gevoel, een stukje Marokko dat je met je meedraagt.'
    },
    blog: {
      title: 'Blog',
      subtitle: 'Welkom bij onze Darija-blog — ontdek Marokko via taal, cultuur en dagelijkse uitdrukkingen.',
      search_placeholder: 'Zoek berichten, tips of plaatsen',
      all: 'Alles',
      featured: 'Aanbevolen',
      recent_posts: 'Recente berichten'
      ,not_found: 'Bericht niet gevonden',
      back_to_blog: 'Terug naar de blog',
      back: 'Terug',
      comments_title: 'Reacties',
      comments_sub: 'Deel je gedachten — wees vriendelijk. Je moet ingelogd zijn om te reageren.',
      commenting_as: 'Reactie als',
      comment_placeholder: 'Schrijf een nuttige reactie...',
      post_comment: 'Plaats reactie',
      clear: 'Wissen',
      not_logged_in: 'Je bent niet ingelogd.',
      to_comment: 'om te reageren.',
      no_comments: 'Nog geen reacties — wees de eerste.'
    },
    dictionary: {
      title: 'Darija Woordenboek',
      subtitle: 'Zoek duizenden Marokkaanse woorden en uitdrukkingen met betekenissen, voorbeelden en uitspraak.',
      search_dar_en: 'Zoek Darija → Engels',
      search_en_dar: 'Zoek Engels → Darija',
      search_fr_dar: 'Zoek Frans → Darija',
      search_es_dar: 'Zoek Spaans → Darija',
      search_it_dar: 'Zoek Italiaans → Darija',
      search_button: 'Zoeken',
      no_results: 'Geen resultaten — probeer een ander woord of verwijder filters.',
      favorites_empty: 'Nog geen opgeslagen woorden. Klik op de ster om op te slaan.'
      ,add_to_favorites: 'Toevoegen aan favorieten',
      remove_from_favorites: 'Verwijderen uit favorieten',
      add_short: '☆',
      remove_short: '★',
      meaning_label: 'Betekenis:',
      examples_title: 'Voorbeelden',
      notes_title: 'Opmerkingen over gebruik',
      notes_text: 'Marokkanen gebruiken vaak'
    },
    translator: {
      title: 'Darija Vertaler',
      description: 'Gebruik onze snelle vertaler om Engels, Frans, Spaans of Italiaans naar Marokkaans Darija te vertalen.',
      from: 'Van',
      to: 'Naar',
      enter_text: 'Voer tekst in om te vertalen',
      translate: 'Vertalen',
      no_translation: 'Nog geen vertaling. Klik op Vertalen.',
      save: 'Opslaan',
      play: 'Afspelen',
      sample_where: 'Waar ben je?',
      sample_howmuch: 'Hoeveel kost dit?',
      sample_hello: 'Hallo'
    },
    pricing: {
      title: 'Kies je plan',
      subtitle: 'ExploreDarija biedt flexibele leerplannen voor beginners, reizigers en gevorderden. Kies het plan dat past bij je doelen.',
      billing: 'Facturering',
      monthly: 'Maandelijks',
      yearly: 'Jaarlijks',
      free: 'Gratis',
      standard: 'Standaard',
      premium: 'Premium+',
      get_started: 'Begin',
      choose_plan: 'Kies plan en begin',
      compare_title: 'Vergelijk plannen',
      faq_title: 'Veelgestelde vragen'
    },
    login: {
      title: 'Inloggen',
      subtitle: 'Log in om je lessen en voortgang voort te zetten.',
      email: 'Email',
      password: 'Wachtwoord',
      sign_in: 'Inloggen'
    },
    terms: {
      title: 'Gebruiksvoorwaarden',
      placeholder: 'Dit zijn tijdelijke voorwaarden voor ExploreDarija. Vervang ze door je eigen voorwaarden.'
    },
    privacy: {
      title: 'Privacy',
      placeholder: 'Dit is een tijdelijke privacyverklaring. Werk deze bij volgens je praktijken.'
    },
    contact: {
      title: 'Contact',
      placeholder: 'Vragen of feedback? Stuur ons een bericht.',
      name: 'Naam',
      email: 'Email',
      message: 'Bericht',
      send: 'Verzenden'
    }
  }
};

export default translations;
