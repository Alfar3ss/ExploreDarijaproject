import './globals.css'
import React from 'react'
import Header from '../components/header'
import Footer from '../components/footer'
import { LanguageProvider } from '../components/language-provider'

export const metadata = {
	title: 'ExploreDarija — Learn Moroccan Arabic (Darija)',
	description: 'Learn Moroccan Arabic (Darija) with interactive lessons, dictionary, and Lhajja AI chat.',
	keywords: ['Darija', 'Moroccan Arabic', 'learn darija', 'language'],
	openGraph: {
		title: 'ExploreDarija — Learn Darija',
		description: 'Learn Moroccan Arabic with interactive lessons and an AI-native Darija chat.',
		url: process.env.SITE_URL || 'https://example.com',
		siteName: 'ExploreDarija',
		images: [`${process.env.SITE_URL || 'https://example.com'}/og-image.png`],
		type: 'website',
	},
	twitter: {
		card: 'summary_large_image',
		title: 'ExploreDarija',
		description: 'Learn Moroccan Arabic (Darija) with lessons and AI chat.',
		images: [`${process.env.SITE_URL || 'https://example.com'}/og-image.png`],
	},
	icons: {
		icon: '/favicon.svg',
		apple: '/favicon.svg',
	},
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
	return (
		<html lang="en">
			<body>
				<LanguageProvider>
					<React.Suspense fallback={null}>
						<Header />
					</React.Suspense>
					{children}
					<React.Suspense fallback={null}>
						<Footer />
					</React.Suspense>
				</LanguageProvider>
			</body>
		</html>
	)
}

