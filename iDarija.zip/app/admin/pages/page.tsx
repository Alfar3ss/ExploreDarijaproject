"use client"
import React from 'react'
import AdminLayout from '../../../components/admin-layout'

export default function AdminPagesPage(){
  return (
    <AdminLayout>
      <div className="max-w-6xl mx-auto p-6">
        <h1 className="text-2xl font-bold mb-4">Pages</h1>
        <p className="text-sm text-gray-600">Manage static pages on your site (About, Contact, Terms).</p>
      </div>
    </AdminLayout>
  )
}
