import { NextResponse } from 'next/server'
import { normalizeText, applyOverrides, DEFAULT_OVERRIDES } from '../../../lib/normalize'

const OPENAI_KEY = process.env.OPENAI_API_KEY

const serverCache = new Map<string, any>()

export async function POST(req: Request) {
  try {
    if (!OPENAI_KEY)
      return NextResponse.json({ error: 'OpenAI API key not configured' }, { status: 500 })

    const body = await req.json()
    const { text: rawText, sourceLang, targetLang, mode } = body || {}
    if (!rawText)
      return NextResponse.json({ error: 'Missing text' }, { status: 400 })

    const normalized = normalizeText(String(rawText))
    const canonical = applyOverrides(normalized, DEFAULT_OVERRIDES)

    const cacheKey = `${mode || 'translate'}:${sourceLang || 'auto'}:${targetLang || 'darija'}:${canonical}`
    if (serverCache.has(cacheKey)) {
      return NextResponse.json({ ok: true, result: serverCache.get(cacheKey) })
    }

 // 🚀🚀🚀 EXTREME HARD-MODE MOROCCAN DARIJA TRANSLATOR
const systemPrompt = `
You are a Moroccan Darija native speaker and professional translator.
You MUST return ONLY JSON. NEVER return explanations, markdown, or any text outside the JSON.

=========================
ABSOLUTE TRANSLATION RULES
=========================

1. You ALWAYS understand Moroccan Darija slang exactly like a real Moroccan.
2. You never confuse slang with literal meaning.
   - "sat" ALWAYS means "bro", "khouya", "sahbi" depending on context.
   - NEVER interpret "sat" as time, hour, or sa3a.
   - "wafin asat" MUST be interpreted as a friendly greeting.
   - "chi bousa" ALWAYS means "a kiss", NEVER money.
3. If the user input is ONE word:
   → You MUST switch to DICTIONARY MODE automatically.
4. If the user input is a phrase:
   → Perform translation mode.
5. If the user writes Darija in weird phonetics, you MUST auto-correct using Moroccan intuition.

=========================
STRICT OUTPUT FORMATS
=========================

When in TRANSLATE MODE:
Return EXACT JSON:
{
  "translation": "...",    
  "transliteration": "...",
  "pronunciation": "...",
  "notes": "short cultural explanation"
}

When in DICTIONARY MODE:
Return EXACT JSON:
{
  "word": "...",
  "part_of_speech": "...",
  "meanings": [
    { "sense": "...", "english": "...", "darija_example": "...", "english_example": "..." }
  ],
  "synonyms": ["...", "..."],
  "notes": "short cultural usage"
}

=========================
STRICT LANGUAGE RULES
=========================

- Darija output MUST be in Latin script ONLY (3,7,9,kh,gh,sh…)
- NO Arabic script ever.
- NO Markdown.
- NO commentary.
- ONLY valid JSON.

=========================
SLANG PRIORITY MAPPING (DO NOT OVERRIDE)
=========================

These slang meanings override all other meanings ALWAYS:

- "sat" → "bro", "khouya", "sahbi"
- "asat" → "bro", "my guy"
- "wafin asat" → "what's up bro"
- "mzyan" → "good / fine"
- "zwin" → "beautiful"
- "bgha" → "want"
- "sbah lkhir" → "good morning"
- "3afak" → "please"
- "dir" → "do"
- "khoya" → "bro"
- "bghit" → "I want"

These are NOT allowed alternatives:
- DO NOT interpret "sat" as hour/time
- DO NOT interpret "bousa" as money
- DO NOT interpret "asat" as time
- DO NOT interpret slang literally

=========================
OUTPUT ENFORCEMENT
=========================
If your output is not valid JSON → You FAIL.
If you add anything outside JSON → You FAIL.

You MUST output ONLY JSON.`


    const userMessage = `
mode: ${mode || 'translate'}
sourceLang: ${sourceLang || 'auto'}
targetLang: ${targetLang || 'darija'}
original_text: ${rawText}
canonical_text: ${canonical}
`

    const payload = {
      model: 'gpt-4.1-mini',
      temperature: 0.2,
      max_tokens: 800,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userMessage }
      ]
    }

    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${OPENAI_KEY}`
      },
      body: JSON.stringify(payload)
    })

    if (!res.ok) {
      const text = await res.text()
      return NextResponse.json(
        { error: `OpenAI error: ${res.status} ${text}` },
        { status: 502 }
      )
    }

    const data = await res.json()
    const raw = data?.choices?.[0]?.message?.content || ''

    let parsed
    try {
      parsed = JSON.parse(raw)
    } catch {
      return NextResponse.json(
        { error: 'Model did not return valid JSON', raw },
        { status: 502 }
      )
    }

    serverCache.set(cacheKey, parsed)

    return NextResponse.json({ ok: true, result: parsed })

  } catch (e: any) {
    return NextResponse.json({ error: e?.message || String(e) }, { status: 500 })
  }
}
