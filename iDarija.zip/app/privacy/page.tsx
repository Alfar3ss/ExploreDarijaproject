import translations from '../../lib/translations'

export const dynamic = 'force-dynamic'

export const metadata = {
  title: 'Privacy — ExploreDarija',
}

export default function PrivacyPage() {
  const t = (key: string) => {
    const parts = key.split('.')
    let cur: any = (translations as any).en
    for (const p of parts) {
      cur = cur?.[p]
      if (cur === undefined) break
    }
    return typeof cur === 'string' ? cur : ''
  }

  return (
    <main className="max-w-4xl mx-auto px-4 md:px-8 py-12">
      <h1 className="text-2xl font-bold mb-4">{t('privacy.title')}</h1>
      <p className="text-gray-700 mb-4">{t('privacy.placeholder')}</p>
      <section className="prose prose-sm text-gray-700">
        <h2>Information Collection</h2>
        <p>We may collect anonymized usage data to improve the service.</p>
        <h2>Cookies</h2>
        <p>We use cookies and local storage for preferences (e.g., language).</p>
      </section>
    </main>
  )
}
