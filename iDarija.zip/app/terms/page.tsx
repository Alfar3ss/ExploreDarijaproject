import translations from '../../lib/translations'

export const metadata = {
  title: 'Terms — ExploreDarija',
}

export const dynamic = 'force-dynamic'

export default function TermsPage() {
  const t = (key: string) => {
    const parts = key.split('.')
    let cur: any = (translations as any).en
    for (const p of parts) {
      cur = cur?.[p]
      if (cur === undefined) break
    }
    return typeof cur === 'string' ? cur : ''
  }

  return (
    <main className="max-w-4xl mx-auto px-4 md:px-8 py-12">
      <h1 className="text-2xl font-bold mb-4">{t('terms.title')}</h1>
      <p className="text-gray-700 mb-4">{t('terms.placeholder')}</p>
      <section className="prose prose-sm text-gray-700">
        <h2>Use of Service</h2>
        <p>By using {t('site.name')} you agree to the terms and conditions. This page should be updated with legal text appropriate to your service.</p>
        <h2>Disclaimer</h2>
        <p>Content is provided for educational purposes and does not constitute professional advice.</p>
      </section>
    </main>
  )
}
