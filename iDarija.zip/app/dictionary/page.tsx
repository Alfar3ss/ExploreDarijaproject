"use client"
import { useEffect, useMemo, useState } from "react"
import Fuse from "fuse.js"
import { MotionDiv } from "../../components/motion-div"
import { useT } from "../../components/use-t"

export const dynamic = 'force-dynamic'

type Entry = {
  id: string
  darija: string
  translit?: string
  meaning: { en?: string; fr?: string; es?: string; it?: string; de?: string }
  type: string
  examples: string[]
  regions?: { name: string; variant: string }[]
  related?: string[]
  categories?: string[]
}

const MOCK: Entry[] = [
  {
    id: "smah",
    darija: "Smah lia",
    translit: "Smaḥ liya",
    meaning: { en: "Pardon me", fr: "Excuse-moi", es: "Perdón", it: "Scusami", de: "Entschuldigung" },
    type: "Expression",
    examples: [
      "Smah lia, ma smaʿt-ksh.",
      "Smah lia, fin tmchi?",
    ],
    regions: [
      { name: "Casablanca", variant: "Smah lia" },
      { name: "Marrakech", variant: "Smah liya" },
    ],
    related: ["Afak", "M3lich"],
    categories: ["Greetings", "Phrases"],
  },
  {
    id: "shukran",
    darija: "Shukran",
    translit: "Shukran",
    meaning: { en: "Thank you", fr: "Merci", es: "Gracias", it: "Grazie", de: "Danke" },
    type: "Expression",
    examples: ["Shukran bzaf.", "Shukran 3la kolshi."],
    related: ["La shukran", "Merhba"],
    categories: ["Politeness", "Phrases"],
  },
  {
    id: "afak",
    darija: "Afak",
    translit: "Afak",
    meaning: { en: "Please / Excuse me (asking)", fr: "S'il vous plaît / excusez-moi", es: "Por favor / disculpe", it: "Per favore / scusa", de: "Bitte / Entschuldigung" },
    type: "Slang",
    examples: ["Afak 3tini l-maya.", "Afak, fin l-bab?"],
    related: ["Smah lia", "M3lich"],
    categories: ["Politeness", "Slang"],
  },
]

// Local dictionary cache stored in localStorage to avoid repeated API calls
function loadDictCache(): Record<string, Entry> {
  try {
    const raw = localStorage.getItem('iDarija_dict_cache')
    return raw ? JSON.parse(raw) : {}
  } catch (e) {
    return {}
  }
}

function saveDictCache(cache: Record<string, Entry>) {
  try { localStorage.setItem('iDarija_dict_cache', JSON.stringify(cache)) } catch (e) {}
}

export default function DictionaryPage() {
  const t = useT()
  const [query, setQuery] = useState("")
  const [fromLang, setFromLang] = useState<'darija'|'en'|'fr'|'es'|'it'|'de'|'auto'>('darija')
  const [toLang, setToLang] = useState<'darija'|'en'|'fr'|'es'|'it'|'de'>('en')
  const [selected, setSelected] = useState<Entry | null>(null)
  const [translatedResult, setTranslatedResult] = useState<{ translation?: string; transliteration?: string; pronunciation?: string; notes?: string } | null>(null)
  const [searchError, setSearchError] = useState<string | null>(null)
  const [tempResults, setTempResults] = useState<Entry[]>([])
  const [loadingSearch, setLoadingSearch] = useState(false)
  const [favorites, setFavorites] = useState<string[]>([])
  const [activeCategory, setActiveCategory] = useState<string | null>(null)

  useEffect(() => {
    try {
      const raw = localStorage.getItem("iDarija_dictionary_favorites")
      if (raw) setFavorites(JSON.parse(raw))
    } catch (e) {}
  }, [])

  useEffect(() => {
    try {
      localStorage.setItem("iDarija_dictionary_favorites", JSON.stringify(favorites))
    } catch (e) {}
  }, [favorites])

  const categories = useMemo(() => {
    const s = new Set<string>()
    MOCK.forEach((m) => m.categories?.forEach((c) => s.add(c)))
    return Array.from(s)
  }, [])

  // Setup Fuse for fuzzy searching across several fields
  const fuse = useMemo(() => {
        const options: Fuse.IFuseOptions<Entry> = {
      keys: [
        { name: "darija", weight: 0.6 },
        { name: "translit", weight: 0.4 },
        { name: "meaning.en", weight: 0.5 },
        { name: "meaning.fr", weight: 0.4 },
        { name: "meaning.de", weight: 0.45 },
        { name: "meaning.es", weight: 0.3 },
        { name: "meaning.it", weight: 0.3 },
        { name: "examples", weight: 0.2 },
      ],
      threshold: 0.4,
      includeScore: true,
      useExtendedSearch: false,
    }
    return new Fuse(MOCK, options)
  }, [])

  const results = useMemo(() => {
    const q = query.trim()
    const byCategory = (arr: Entry[]) => (activeCategory ? arr.filter((e) => e.categories?.includes(activeCategory)) : arr)
    if (!q) return byCategory(MOCK)

    // Use Fuse to search
    const fuseRes = fuse.search(q)
    const items = fuseRes.map((r) => r.item)
    return byCategory(items)
  }, [query, activeCategory, fuse])

  const langLabel = (l: string) => {
    switch (l) {
      case 'en': return 'English'
      case 'fr': return 'French'
      case 'es': return 'Spanish'
      case 'it': return 'Italian'
      case 'de': return 'German'
      case 'darija': return 'Darija'
      case 'auto': return 'Auto'
      default: return l
    }
  }

  async function handleSearch() {
    const q = query.trim()
    if (!q) return
    setSearchError(null)
    setTempResults([])
    setLoadingSearch(true)

    // detect Latin input (e.g., user typed English) even if direction is dar-en
    const looksLikeLatin = /[A-Za-z]/.test(q)

    // If user is searching with exactly one side Darija, try translating first
    // Also auto-detect when user typed Latin in a Darija box
    const fromIsDarija = fromLang === 'darija'
    const toIsDarija = toLang === 'darija'

    // Enforce: only proceed with translation when exactly one side is Darija
    if (fromIsDarija === toIsDarija) {
      // both darija or both non-darija -> fall back to local lookup
    } else {
      // determine source language for the translate API
      // If the user explicitly selected `From = Darija`, prefer `darija` even when input is Latin-script.
      // This avoids accidental auto-detection (e.g., 'sat' detected as English 'sat' -> 'qa3d').
      let src = ''
      if (fromIsDarija) {
        src = 'darija'
      } else if (fromLang === 'auto') {
        src = 'auto'
      } else {
        src = fromLang
      }

      // Normalize query and apply overrides for cache lookup
      // import normalize helpers lazily to avoid client bundle issues
      // (module exists in TS build) - simple inline normalization here
      const normalizeForCache = (s: string) =>
        s
          .trim()
          .toLowerCase()
          .replace(/[^\w\u00C0-\u024F\s'’-]+/g, ' ')
          .replace(/\s+/g, ' ')
          .trim()
      const normalizedQ = normalizeForCache(q)
      // Check local cache first: key is `${src}:${normalized query}`
      const cacheKey = `${src}:${normalizedQ}`
      const cache = loadDictCache()
      if (cache[cacheKey]) {
        const cached = cache[cacheKey]
        setSelected(cached)
        setTempResults([cached])
        setLoadingSearch(false)
        return
      }

      // Check server-side cache (if available). This avoids hitting the OpenAI API
      try {
        const serverRes = await fetch(`/api/dictionary-cache?key=${encodeURIComponent(cacheKey)}`)
        if (serverRes.ok) {
          const serverJson = await serverRes.json()
          if (serverJson?.found && serverJson.entry) {
            // Save to local cache for faster subsequent lookups in the browser
            try {
              const c = loadDictCache()
              c[cacheKey] = serverJson.entry
              saveDictCache(c)
            } catch (e) {}
            setSelected(serverJson.entry)
            setTempResults([serverJson.entry])
            setLoadingSearch(false)
            return
          }
        }
      } catch (e) {
        // ignore server cache failures and continue (we'll fallback to translate API)
        console.warn('Server dictionary cache check failed', e)
      }
      try {
        if (!fromIsDarija) {
          // Translate user input (other language) into Darija first
          const res = await fetch('/api/translate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: q, sourceLang: src, targetLang: 'darija', mode: 'translate' })
          })
          const json = await res.json()
          if (!res.ok) {
            console.warn('Translate API error', json)
            setTranslatedResult(null)
            setSearchError(json?.error || 'Translation service unavailable')
            // fallback to a tiny local mapping for a few common phrases
            const fallbackMap: Record<string, string> = {
              'hello': 'salam',
              'where are you?': 'fin kayn?',
              'where are you': 'fin kayn?',
              'how much is this?': 'bsh7al hadshi?',
              'how much is this': 'bsh7al hadshi?'
            }
            const f = fallbackMap[q.toLowerCase()]
            if (f) {
              const meaningFallback: any = { en: '', fr: '', es: '', it: '', de: '' }
              meaningFallback[toLang] = q
              const gen: Entry = {
                id: `gen-${Date.now()}`,
                darija: f,
                translit: f,
                meaning: meaningFallback,
                type: 'Generated',
                examples: [],
              }
              setSelected(gen)
              setTempResults([gen])
              setLoadingSearch(false)
              return
            }
          } else {
            const parsed = json.result || {}
            const translation = parsed.translation || parsed.translations?.[0]?.text || ''
            const transliteration = parsed.transliteration || ''
            setTranslatedResult({ translation, transliteration, pronunciation: parsed.pronunciation, notes: parsed.notes })

            // search using the translated Darija text
            if (translation) {
              const fuseRes = fuse.search(translation)
              const items = fuseRes.map((r) => r.item)
              if (items.length) {
                setSelected(items[0])
                setTempResults([])
                setLoadingSearch(false)
                return
              }
              // no exact match — ask the model to generate a dictionary entry in the requested target language
              try {
                const dictRes = await fetch('/api/translate', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ text: translation, sourceLang: 'darija', targetLang: toLang, mode: 'dictionary' })
                })
                const dictJson = await dictRes.json()
                if (dictRes.ok && dictJson?.result) {
                  const p = dictJson.result
                  const word = p.word || translation
                  const translitField = p.transliteration || transliteration || ''
                  const part = p.part_of_speech || 'Expression'
                  const translationsArr: Array<{ lang?: string; text?: string }> = p.translations || []
                  const meaningObj: any = { en: '', fr: '', es: '', it: '', de: '' }
                  translationsArr.forEach((tr: any) => {
                    const l = (tr.lang || '').toLowerCase()
                    if (l.startsWith('en')) meaningObj.en = tr.text || meaningObj.en
                    if (l.startsWith('fr')) meaningObj.fr = tr.text || meaningObj.fr
                    if (l.startsWith('es')) meaningObj.es = tr.text || meaningObj.es
                    if (l.startsWith('it')) meaningObj.it = tr.text || meaningObj.it
                    if (l.startsWith('de')) meaningObj.de = tr.text || meaningObj.de
                    // also set the requested target language if present
                    if (l.startsWith(toLang)) meaningObj[toLang] = tr.text || meaningObj[toLang]
                  })
                  const examplesArr: string[] = (p.examples || []).map((ex: any) => {
                    if (typeof ex === 'string') return ex
                    return ex.source ? `${ex.source}${ex.translation ? ' — ' + ex.translation : ''}` : JSON.stringify(ex)
                  })
                  const regionsArr = (p.regional_variants || []).map((r: any) => ({ name: r.name || 'Region', variant: r.variant || r.text || '' }))
                  const relatedArr = p.synonyms || p.related || []
                  const categoriesArr = p.categories || (part ? [part] : [])
                  const gen: Entry = {
                    id: `gen-${Date.now()}`,
                    darija: word,
                    translit: translitField,
                    meaning: {
                      en: meaningObj.en || q,
                      fr: meaningObj.fr,
                      es: meaningObj.es,
                      it: meaningObj.it,
                      de: meaningObj.de,
                    },
                    type: part,
                    examples: examplesArr,
                    regions: regionsArr.length ? regionsArr : undefined,
                    related: relatedArr.length ? relatedArr : undefined,
                    categories: categoriesArr.length ? categoriesArr : undefined,
                  }
                  try {
                    const cache = loadDictCache()
                    cache[cacheKey] = gen
                    saveDictCache(cache)
                  } catch (e) {}
                  try {
                    fetch('/api/dictionary-cache', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ cacheKey, sourceLang: 'darija', queryText: translation, entry: gen })
                    }).catch((err) => console.warn('Failed to write server dictionary cache', err))
                  } catch (e) {}
                  setSelected(gen)
                  setTempResults([gen])
                  setLoadingSearch(false)
                  return
                }
              } catch (err) {
                console.warn('Dictionary lookup failed', err)
              }
              // fallback simple generated entry
              const gen: Entry = {
                id: `gen-${Date.now()}`,
                darija: translation,
                translit: transliteration,
                meaning: { en: q },
                type: 'Generated',
                examples: [],
              }
              try {
                const cache = loadDictCache()
                cache[cacheKey] = gen
                saveDictCache(cache)
              } catch (e) {}
              setSelected(gen)
              setTempResults([gen])
              setLoadingSearch(false)
              return
            }
          }
        } else {
          // fromIsDarija === true: user typed Darija and wants translation into `toLang` or lookup
          const darijaTerm = q
          const fuseRes = fuse.search(darijaTerm)
          const items = fuseRes.map((r) => r.item)
          if (items.length) {
            setSelected(items[0])
            setTempResults([])
            setLoadingSearch(false)
            return
          }

          // ask model for a dictionary-style entry with translations into requested language
          try {
            const dictRes = await fetch('/api/translate', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ text: darijaTerm, sourceLang: 'darija', targetLang: toLang, mode: 'dictionary' })
            })
            const dictJson = await dictRes.json()
            if (dictRes.ok && dictJson?.result) {
              const p = dictJson.result
              const word = p.word || darijaTerm
              const translitField = p.transliteration || ''
              const part = p.part_of_speech || 'Expression'
              const translationsArr: Array<{ lang?: string; text?: string }> = p.translations || []
              const meaningObj: any = { en: '', fr: '', es: '', it: '', de: '' }
              translationsArr.forEach((tr: any) => {
                const l = (tr.lang || '').toLowerCase()
                if (l.startsWith('en')) meaningObj.en = tr.text || meaningObj.en
                if (l.startsWith('fr')) meaningObj.fr = tr.text || meaningObj.fr
                if (l.startsWith('es')) meaningObj.es = tr.text || meaningObj.es
                if (l.startsWith('it')) meaningObj.it = tr.text || meaningObj.it
                if (l.startsWith('de')) meaningObj.de = tr.text || meaningObj.de
                if (l.startsWith(toLang)) meaningObj[toLang] = tr.text || meaningObj[toLang]
              })
              const examplesArr: string[] = (p.examples || []).map((ex: any) => {
                if (typeof ex === 'string') return ex
                return ex.source ? `${ex.source}${ex.translation ? ' — ' + ex.translation : ''}` : JSON.stringify(ex)
              })
              const regionsArr = (p.regional_variants || []).map((r: any) => ({ name: r.name || 'Region', variant: r.variant || r.text || '' }))
              const relatedArr = p.synonyms || p.related || []
              const categoriesArr = p.categories || (part ? [part] : [])
              const gen: Entry = {
                id: `gen-${Date.now()}`,
                darija: word,
                translit: translitField,
                meaning: {
                  en: meaningObj.en || q,
                  fr: meaningObj.fr,
                  es: meaningObj.es,
                  it: meaningObj.it,
                  de: meaningObj.de,
                },
                type: part,
                examples: examplesArr,
                regions: regionsArr.length ? regionsArr : undefined,
                related: relatedArr.length ? relatedArr : undefined,
                categories: categoriesArr.length ? categoriesArr : undefined,
              }
              try {
                const cache = loadDictCache()
                cache[cacheKey] = gen
                saveDictCache(cache)
              } catch (e) {}
              try {
                fetch('/api/dictionary-cache', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ cacheKey, sourceLang: 'darija', queryText: darijaTerm, entry: gen })
                }).catch((err) => console.warn('Failed to write server dictionary cache', err))
              } catch (e) {}
              setSelected(gen)
              setTempResults([gen])
              setLoadingSearch(false)
              return
            }
          } catch (err) {
            console.warn('Dictionary lookup failed', err)
          }
          // fallback generated entry
          const meaningFallback2: any = { en: '', fr: '', es: '', it: '', de: '' }
          meaningFallback2[toLang] = q
          const gen: Entry = {
            id: `gen-${Date.now()}`,
            darija: darijaTerm,
            translit: '',
            meaning: meaningFallback2,
            type: 'Generated',
            examples: [],
          }
          try {
            const cache = loadDictCache()
            cache[cacheKey] = gen
            saveDictCache(cache)
          } catch (e) {}
          setSelected(gen)
          setTempResults([gen])
          setLoadingSearch(false)
          return
        }
      } catch (e) {
        console.warn('Translate call failed', e)
        setSearchError('Translation request failed')
        setLoadingSearch(false)
      }
    }

    // fallback: run local search on whatever the user typed
    const fuseRes = fuse.search(q)
    const items = fuseRes.map((r) => r.item)
    if (items.length) {
      setSelected(items[0])
      setTempResults([])
      setLoadingSearch(false)
    } else {
      setSelected(null)
      setTempResults([])
      setLoadingSearch(false)
    }
  }

  function playAudio(text: string) {
    try {
      const utter = new SpeechSynthesisUtterance(text)
      // prefer Moroccan Arabic if available
      utter.lang = "ar-MA"
      speechSynthesis.cancel()
      speechSynthesis.speak(utter)
    } catch (e) {
      console.warn("TTS not available", e)
    }
  }

  function toggleFavorite(id: string) {
    setFavorites((prev) => {
      if (prev.includes(id)) return prev.filter((p) => p !== id)
      return [...prev, id]
    })
  }

  return (
    <main className="min-h-screen bg-white text-gray-800">
      <section className="max-w-6xl mx-auto py-12 px-6">
        <MotionDiv>
          <h1 className="text-4xl font-bold mb-2">{t('dictionary.title')}</h1>
          <p className="text-gray-600 mb-6">{t('dictionary.subtitle')}</p>
        </MotionDiv>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm">
              {/* Translation widget removed — dictionary page is for dictionary-only lookups */}
              <div className="flex flex-col md:flex-row gap-3 md:items-center">
                <input
                  value={query}
                  onChange={(e) => { setQuery(e.target.value); setTranslatedResult(null) }}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleSearch() } }}
                  placeholder={fromLang === 'darija' ? `Darija → ${langLabel(toLang)}` : `${langLabel(fromLang)} → Darija`}
                  className="flex-1 px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/30"
                />

                <div className="flex gap-2">
                  <select value={fromLang} onChange={(e) => {
                    const v = e.target.value as any
                    if (v === 'darija') {
                      setFromLang('darija')
                      if (toLang === 'darija') setToLang('en')
                    } else {
                      setFromLang(v)
                      if (toLang !== 'darija') setToLang('darija')
                    }
                  }} className="text-sm px-3 py-2 border rounded-lg">
                    <option value="darija">Darija</option>
                    <option value="en">English</option>
                    <option value="fr">French</option>
                    <option value="es">Spanish</option>
                    <option value="it">Italian</option>
                    <option value="de">German</option>
                    <option value="auto">Auto</option>
                  </select>

                  <select value={toLang} onChange={(e) => {
                    const v = e.target.value as any
                    if (v === 'darija') {
                      setToLang('darija')
                      if (fromLang === 'darija') setFromLang('en')
                    } else {
                      setToLang(v)
                      if (fromLang !== 'darija') setFromLang('darija')
                    }
                  }} className="text-sm px-3 py-2 border rounded-lg">
                    <option value="darija">Darija</option>
                    <option value="en">English</option>
                    <option value="fr">French</option>
                    <option value="es">Spanish</option>
                    <option value="it">Italian</option>
                    <option value="de">German</option>
                  </select>
                </div>
                <button onClick={() => handleSearch()} className="px-4 py-2 bg-primary text-white rounded-lg">{t('dictionary.search_button')}</button>
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                <button onClick={() => setQuery('')} className={`px-3 py-1 text-sm rounded-full border ${activeCategory === null ? 'bg-primary/10 border-primary/30' : 'bg-white'}`}>{t('blog.all')}</button>
                {categories.map((c) => (
                  <button key={c} onClick={() => setActiveCategory((s) => (s === c ? null : c))} className={`px-3 py-1 text-sm rounded-full border ${activeCategory === c ? 'bg-primary/10 border-primary/30' : 'bg-white'}`}>{c}</button>
                ))}
              </div>

              {/* Translation result panel (shows API-generated translation in the chosen language) */}
              <div className="mt-4">
                <div className="text-sm text-gray-600">Result</div>
                <div className="mt-2 p-3 border rounded min-h-[60px] bg-gray-50">
                  {translatedResult ? (
                    <div>
                      <div className="font-medium mb-1">{translatedResult.translation}</div>
                      {translatedResult.transliteration && <div className="text-sm text-gray-600">{translatedResult.transliteration}</div>}
                      {translatedResult.pronunciation && <div className="mt-2 text-sm text-gray-600">{translatedResult.pronunciation}</div>}
                      {translatedResult.notes && <div className="mt-2 text-sm text-gray-600">{translatedResult.notes}</div>}
                    </div>
                  ) : (
                    <div className="text-sm text-gray-500">No translation yet</div>
                  )}
                </div>
              </div>

              <div className="mt-6">
                {searchError && <div className="text-sm text-red-600 mb-2">{searchError}</div>}
                { (results.length === 0 && tempResults.length === 0) ? (
                  <div className="text-gray-600">{t('dictionary.no_results')}</div>
                ) : (
                  <ul className="space-y-2">
                    {[...results, ...tempResults].map((r) => (
                      <li key={r.id} className="p-3 border border-gray-100 rounded-lg hover:bg-gray-50 cursor-pointer" onClick={() => setSelected(r)}>
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-semibold">{r.darija} {r.translit ? <span className="text-sm text-gray-500">— {r.translit}</span> : null}</div>
                            <div className="text-sm text-gray-600">{r.meaning.en}</div>
                          </div>
                          <div className="flex items-center gap-3">
                            <button title={t('translator.play')} onClick={(e) => { e.stopPropagation(); playAudio(r.darija) }} className="text-sm px-3 py-1 bg-gray-100 rounded">🔊 {t('translator.play')}</button>
                            <button title={favorites.includes(r.id) ? t('dictionary.remove_from_favorites') : t('dictionary.add_to_favorites')} onClick={(e) => { e.stopPropagation(); toggleFavorite(r.id) }} className="text-sm px-3 py-1 rounded border">{favorites.includes(r.id) ? t('dictionary.remove_short') : t('dictionary.add_short')}</button>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>

            {/* Selected word panel */}
            {selected ? (
              <div className="mt-6 bg-white border border-gray-100 rounded-2xl p-6 shadow-sm">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h2 className="text-2xl font-bold">{selected.darija}</h2>
                    {selected.translit && <div className="text-sm text-gray-600">{selected.translit}</div>}
                    <div className="mt-2 text-gray-700"><strong>{t('dictionary.meaning_label')}</strong> {selected.meaning.en} {selected.meaning.fr ? <span className="text-gray-600">/ {selected.meaning.fr}</span> : null} {selected.meaning.es ? <span className="text-gray-600">/ {selected.meaning.es}</span> : null} {selected.meaning.it ? <span className="text-gray-600">/ {selected.meaning.it}</span> : null} {selected.meaning.de ? <span className="text-gray-600">/ {selected.meaning.de}</span> : null}</div>
                    <div className="mt-3 flex items-center gap-3">
                      <button onClick={() => playAudio(selected.darija)} className="px-3 py-2 bg-primary text-white rounded">🔊 {t('translator.play')}</button>
                      <button onClick={() => toggleFavorite(selected.id)} className="px-3 py-2 border rounded">{favorites.includes(selected.id) ? t('dictionary.remove_from_favorites') : t('dictionary.add_to_favorites')}</button>
                    </div>
                  </div>

                  <div className="w-48 text-sm text-gray-600">
                    <div><strong>Type:</strong> {selected.type}</div>
                    {selected.regions && (
                      <div className="mt-3">
                        <strong>Regional variations</strong>
                        <ul className="mt-1">
                          {selected.regions.map((r) => (
                            <li key={r.name} className="text-sm">{r.name}: <span className="text-gray-700">{r.variant}</span></li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>

                <div className="mt-4">
                  <strong>Examples</strong>
                  <ul className="mt-2 list-disc pl-5 text-gray-700">
                    {selected.examples.map((ex, i) => <li key={i}>{ex}</li>)}
                  </ul>
                </div>

                <div className="mt-4 text-gray-700">
                  <strong>{t('dictionary.notes_title')}</strong>
                  <p className="mt-2">{t('dictionary.notes_text',)} <em>{selected.darija}</em>.</p>
                </div>

                {selected.related && (
                  <div className="mt-4">
                    <strong>Related words</strong>
                    <div className="mt-2 flex gap-2 flex-wrap">
                      {selected.related.map((r) => (
                        <button key={r} onClick={() => setQuery(r)} className="px-3 py-1 border rounded text-sm">{r}</button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : null}
          </div>

          {/* Right column: favorites & CTAs */}
          <aside className="space-y-4">
            <div className="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm">
              <h4 className="font-semibold mb-2">Favorites</h4>
              {favorites.length === 0 ? (
                <div className="text-gray-600">No saved words yet. Click the star to save.</div>
              ) : (
                <ul className="space-y-2">
                  {favorites.map((id) => {
                    const e = MOCK.find((m) => m.id === id)
                    if (!e) return null
                    return (
                      <li key={id} className="flex items-center justify-between">
                        <button onClick={() => setSelected(e)} className="text-left">
                          <div className="font-medium">{e.darija}</div>
                          <div className="text-sm text-gray-600">{e.meaning.en}</div>
                        </button>
                        <button onClick={() => toggleFavorite(id)} className="text-sm px-2 py-1 border rounded">Remove</button>
                      </li>
                    )
                  })}
                </ul>
              )}
            </div>

            <div className="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm">
              <h4 className="font-semibold">Explore</h4>
              <div className="mt-3 flex flex-col gap-2">
                <a className="px-3 py-2 bg-primary text-white rounded text-center" href="/translator">Practice with Translator</a>
                <a className="px-3 py-2 border rounded text-center" href="/pricing">Explore Lessons & Pricing</a>
                <a className="px-3 py-2 border rounded text-center" href="/login">Join Zoom Classes</a>
              </div>
            </div>
          </aside>
        </div>
      </section>
    </main>
  )
}
