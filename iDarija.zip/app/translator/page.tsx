"use client"
import { useEffect, useMemo, useState } from "react"
import { MotionDiv } from "../../components/motion-div"
import { useT } from "../../components/use-t"
import TranslateWidget from '../../components/translate-widget'

type Lang = "en" | "fr" | "es" | "it" | "de" | "dar"

const LANG_LABEL: Record<Lang, string> = {
  en: "English",
  fr: "French",
  es: "Spanish",
  it: "Italian",
  de: "German",
  dar: "Darija",
}

export const dynamic = 'force-dynamic'

// A tiny mock translator for a few example phrases; fallback returns a placeholder.
function mockTranslate(text: string, from: Lang, to: Lang) {
  const key = text.trim().toLowerCase()
  const examples: Record<string, Partial<Record<Lang, string>>> = {
    "where are you?": {
      en: "Where are you?",
      fr: "Où es-tu ?",
      es: "¿Dónde estás?",
      it: "Dove sei?",
      dar: "Fin kayn?",
    },
    "how much is this?": {
      en: "How much is this?",
      fr: "Combien ça coûte ?",
      es: "¿Cuánto cuesta esto?",
      it: "Quanto costa?",
      dar: "Bsh7al hadshi?",
    },
    "hello": {
      en: "Hello",
      fr: "Bonjour",
      es: "Hola",
      it: "Ciao",
      dar: "Salam",
    },
  }

  // If exact example exists, return the target language variant.
  for (const ex in examples) {
    if (key === ex) {
      const v = examples[ex][to]
      if (v) return v
      break
    }
  }

  // Otherwise, simple placeholder: indicate direction and echo.
  if (to === "dar") return `${text} — (Darija translation placeholder)`
  if (from === "dar") return `${text} — (English translation placeholder)`
  return `${text} — (translated to ${LANG_LABEL[to]})`
}

export default function TranslatorPage() {
  const t = useT()
  const [fromLang, setFromLang] = useState<Lang>("en")
  const [toLang, setToLang] = useState<Lang>("dar")
  // remember user's preferred non-Darija language so switching to/from Darija restores it
  const [otherPref, setOtherPref] = useState<Lang>("en")
  const [input, setInput] = useState("")
  const [output, setOutput] = useState("")
  const [favorites, setFavorites] = useState<Array<{ id: string; from: Lang; to: Lang; input: string; output: string }>>([])

  useEffect(() => {
    try {
      const raw = localStorage.getItem("iDarija_favorites")
      if (raw) setFavorites(JSON.parse(raw))
    } catch (e) {}
  }, [])

  useEffect(() => {
    try {
      localStorage.setItem("iDarija_favorites", JSON.stringify(favorites))
    } catch (e) {}
  }, [favorites])

  // keep mockTranslate as fallback but use TranslateWidget for real requests
  const translate = () => {
    if (!input.trim()) return setOutput("")
    const result = mockTranslate(input, fromLang, toLang)
    setOutput(result)
  }

  const swap = () => {
    const newFrom = toLang
    const newTo = fromLang
    // enforce invariant: exactly one of from/to should be dar
    if (newFrom !== 'dar' && newTo !== 'dar') {
      // prefer keeping otherPref as the non-dar and set the other side to dar
      setFromLang(newFrom)
      setToLang('dar')
      setOtherPref(newFrom)
    } else if (newFrom === 'dar' && newTo === 'dar') {
      // unlikely, but default to english
      setFromLang('en')
      setToLang('dar')
      setOtherPref('en')
    } else {
      setFromLang(newFrom)
      setToLang(newTo)
      if (newFrom !== 'dar') setOtherPref(newFrom)
      if (newTo !== 'dar') setOtherPref(newTo)
    }
    setOutput("")
  }

  const playAudio = (text: string, lang: Lang) => {
    if (!text) return
    try {
      const utter = new SpeechSynthesisUtterance(text)
      // choose voice locale best-effort
      const langMap: Record<Lang, string> = { en: "en-US", fr: "fr-FR", es: "es-ES", it: "it-IT", de: "de-DE", dar: "ar-MA" }
      utter.lang = langMap[lang] || "en-US"
      window.speechSynthesis.cancel()
      window.speechSynthesis.speak(utter)
    } catch (e) {
      console.warn("Speech synthesis not available", e)
    }
  }

  const saveFavorite = () => {
    if (!input.trim() || !output.trim()) return
    const id = Date.now().toString()
    const item = { id, from: fromLang, to: toLang, input, output }
    setFavorites((s) => [item, ...s])
  }

  const removeFavorite = (id: string) => setFavorites((s) => s.filter((f) => f.id !== id))

  const relatedWords = useMemo(() => {
    // naive related words: split and suggest first word variations
    const words = input.trim().split(/\s+/).filter(Boolean)
    if (!words.length) return []
    const w = words[0].toLowerCase()
    return [w, `${w}s`, `${w}ing`].slice(0, 5)
  }, [input])

  return (
    <main className="min-h-screen bg-white text-gray-800">
      <section className="max-w-4xl mx-auto py-12 px-6">
        <MotionDiv>
          <h1 className="text-3xl font-bold">{t('translator.title')}</h1>
          <p className="mt-2 text-gray-600">{t('translator.description')}</p>
        </MotionDiv>

        <div className="mt-6 grid gap-6 md:grid-cols-3 items-start">
          <div className="md:col-span-2 bg-white border border-gray-100 rounded-2xl p-6 shadow-sm">
            <div className="flex gap-3 items-center">
              <div>
                <label className="text-sm text-gray-600">{t('translator.from')}</label>
                <select
                  value={fromLang}
                  onChange={(e) => {
                    const v = e.target.value as Lang
                    if (v !== 'dar') {
                      setFromLang(v)
                      setToLang('dar')
                      setOtherPref(v)
                    } else {
                      setFromLang('dar')
                      setToLang(otherPref)
                    }
                  }}
                  className="ml-2 border border-gray-200 px-3 py-2 rounded-lg shadow-sm bg-white focus:outline-none focus:ring-2 focus:ring-primary/20"
                >
                  <option value="en">English</option>
                  <option value="fr">French</option>
                  <option value="es">Spanish</option>
                  <option value="it">Italian</option>
                  <option value="de">German</option>
                  <option value="dar">Darija</option>
                </select>
              </div>

              <button onClick={swap} className="p-2 border rounded-full hover:bg-gray-100 transition" aria-label="Swap languages" title="Swap languages">
                <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 text-gray-700" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M3 7h13M3 7l4-4M3 7l4 4M21 17H8M21 17l-4-4M21 17l-4 4" />
                </svg>
              </button>

              <div>
                <label className="text-sm text-gray-600">{t('translator.to')}</label>
                <select
                  value={toLang}
                  onChange={(e) => {
                    const v = e.target.value as Lang
                    if (v !== 'dar') {
                      setToLang(v)
                      setFromLang('dar')
                      setOtherPref(v)
                    } else {
                      setToLang('dar')
                      setFromLang(otherPref)
                    }
                  }}
                  className="ml-2 border border-gray-200 px-3 py-2 rounded-lg shadow-sm bg-white focus:outline-none focus:ring-2 focus:ring-primary/20"
                >
                  {fromLang !== 'dar' ? (
                    <>
                      <option value="dar">Darija</option>
                    </>
                  ) : (
                    <>
                      <option value="en">English</option>
                      <option value="fr">French</option>
                      <option value="es">Spanish</option>
                      <option value="it">Italian</option>
                      <option value="de">German</option>
                    </>
                  )}
                </select>
              </div>
            </div>

            <div className="mt-4">
              <label className="block text-sm text-gray-600">{t('translator.enter_text')}</label>
              <TranslateWidget initialFrom={fromLang} initialTo={toLang} autosuggest onSave={(text, res) => { setInput(text); setOutput(res.translation || '') }} />

              <div className="flex flex-wrap gap-3 mt-4">
                <button onClick={() => { setInput('Where are you?'); setOutput('') }} className="px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition">{t('translator.sample_where')}</button>
                <button onClick={() => { setInput('How much is this?'); setOutput('') }} className="px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition">{t('translator.sample_howmuch')}</button>
                <button onClick={() => { setInput('Hello'); setOutput('') }} className="px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition">{t('translator.sample_hello')}</button>
              </div>

              <div className="mt-5">
                <label className="block text-sm text-gray-600">Translation</label>
                <div className="mt-2 p-4 border border-gray-100 rounded-xl min-h-[80px] bg-white shadow-sm">
                  {output ? (
                    <div>
                      <div className="flex items-center gap-3 justify-between">
                        <div className="font-medium text-gray-800">{output}</div>
                        <div className="flex items-center gap-2">
                            <button onClick={() => playAudio(output, toLang)} className="px-3 py-1 bg-gray-100 rounded-lg text-sm hover:bg-gray-200 transition">{t('translator.play')}</button>
                            <button onClick={saveFavorite} className="px-3 py-1 bg-gray-50 border border-gray-200 rounded-lg text-sm hover:bg-gray-100 transition">{t('translator.save')}</button>
                        </div>
                      </div>
                      <div className="mt-3 text-sm text-gray-600">Example sentence: {mockTranslate('Where are you?', fromLang, toLang)}</div>
                    </div>
                  ) : (
                      <div className="text-gray-500">{t('translator.no_translation')}</div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <aside className="md:col-span-1 space-y-4">
            <div className="p-4 bg-white border border-gray-100 rounded-xl shadow-sm">
              <h4 className="font-semibold">Related words</h4>
              <div className="mt-3 text-gray-600 space-y-2">
                {relatedWords.length ? relatedWords.map((r) => (
                    <div key={r} className="flex items-center justify-between">
                    <span className="text-sm text-gray-800">{r}</span>
                    <button onClick={() => { setInput(r); setOutput('') }} className="text-primary text-sm">Use</button>
                  </div>
                )) : <div className="text-gray-400">Type text to see related words</div>}
              </div>
            </div>

            <div className="p-4 bg-white border border-gray-100 rounded-xl shadow-sm">
              <h4 className="font-semibold">Favorites</h4>
              <div className="mt-3 space-y-3">
                {favorites.length ? favorites.map((f) => (
                  <div key={f.id} className="p-3 bg-gray-50 border border-gray-100 rounded-lg flex items-start justify-between">
                    <div className="max-w-[60%]">
                      <div className="text-sm font-medium text-gray-800 truncate">{f.input}</div>
                      <div className="text-sm text-gray-600 truncate">{f.output}</div>
                    </div>
                    <div className="flex flex-col gap-2 ml-3">
                      <button onClick={() => playAudio(f.output, f.to)} className="px-2 py-1 bg-white border rounded text-sm hover:bg-gray-50">Play</button>
                      <button onClick={() => { setInput(f.input); setOutput(f.output) }} className="px-2 py-1 bg-white border rounded text-sm hover:bg-gray-50">Load</button>
                      <button onClick={() => removeFavorite(f.id)} className="px-2 py-1 text-red-600 bg-white border rounded text-sm hover:bg-red-50">Remove</button>
                    </div>
                  </div>
                )) : <div className="text-gray-400">No favorites yet</div>}
              </div>
            </div>

            <div className="p-4 bg-white border border-gray-100 rounded-xl shadow-sm">
              <h4 className="font-semibold">About Darija</h4>
              <p className="mt-2 text-sm text-gray-600">Darija is a spoken language, not a fully standardized written language. Spellings may vary depending on regions, but the meaning stays the same.</p>
            </div>
          </aside>
        </div>

        <div className="mt-8 text-center">
          <a href="/lessons" className="px-4 py-2 bg-primary text-white rounded-md mr-2">Learn more in our Darija Lessons</a>
          <a href="/pricing" className="px-4 py-2 border rounded-md mr-2">Practice with a coach</a>
          <a href="/dictionary" className="px-4 py-2 border rounded-md">Explore the Dictionary</a>
        </div>
      </section>
    </main>
  )
}
