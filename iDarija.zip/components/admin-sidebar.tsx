"use client"
import Link from 'next/link'
import React, { useEffect, useState } from 'react'
import { usePathname } from 'next/navigation'

function Icon({ children }: { children: React.ReactNode }){
  return <span className="w-5 h-5 inline-block align-middle">{children}</span>
}

export default function AdminSidebar({ compact = false }: { compact?: boolean }) {
  const pathname = usePathname()
  const [hash, setHash] = useState('')

  useEffect(()=>{
    const update = ()=> setHash(window.location.hash || '')
    update()
    window.addEventListener('hashchange', update)
    return ()=> window.removeEventListener('hashchange', update)
  }, [])

  function linkClass(active: boolean){
    const base = 'flex items-center gap-3 px-3 py-2 rounded transition-colors'
    const act = active ? 'bg-gray-700 text-white border-l-4 border-primary' : 'text-gray-200 hover:bg-gray-700'
    return `${base} ${act}`
  }

  const isActive = (href: string)=>{
    if (href === '/admin') return pathname === '/admin' && !hash
    if (href.startsWith('/admin#')) return pathname === '/admin' && hash === href.slice('/admin'.length)
    return pathname === href
  }

  const Item = ({ href, label, icon }: { href: string; label: string; icon: React.ReactNode }) => (
    <Link href={href} className={linkClass(isActive(href))} title={compact ? label : undefined}>
      <div className={`w-6 h-6 flex items-center justify-center ${compact ? 'mx-auto' : ''}`}>{icon}</div>
      <span className={`${compact ? 'hidden' : 'align-middle'}`}>{label}</span>
    </Link>
  )

  return (
    <nav className="space-y-1 text-sm">
      <Item href="/admin" label="Dashboard" icon={<svg viewBox="0 0 24 24" fill="none" className="w-5 h-5"><path d="M3 13h8V3H3v10zm10 8h8V3h-8v18zM3 21h8v-6H3v6z" fill="currentColor"/></svg>} />
      <Item href="/admin/posts" label="Posts" icon={<svg viewBox="0 0 24 24" fill="none" className="w-5 h-5"><path d="M4 6h16v2H4V6zm0 5h10v2H4v-2zm0 5h16v2H4v-2z" fill="currentColor"/></svg>} />
      <Item href="/admin/media" label="Media" icon={<svg viewBox="0 0 24 24" fill="none" className="w-5 h-5"><path d="M21 19V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14h18zM8 11l2.5 3 2-2.5L16 17H6l2-6z" fill="currentColor"/></svg>} />
      <Item href="/admin/pages" label="Pages" icon={<svg viewBox="0 0 24 24" fill="none" className="w-5 h-5"><path d="M6 2h9l5 5v13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1z" fill="currentColor"/></svg>} />
      <Item href="/admin/comments" label="Comments" icon={<svg viewBox="0 0 24 24" fill="none" className="w-5 h-5"><path d="M21 6h-2V4a2 2 0 0 0-2-2H7v2H5a2 2 0 0 0-2 2v11l4-2h10a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2z" fill="currentColor"/></svg>} />
      <Item href="/admin/appearance" label="Appearance" icon={<svg viewBox="0 0 24 24" fill="none" className="w-5 h-5"><path d="M12 3l4 8 8 .5-6.5 5 2 9L12 18l-7.5 7.5 2-9L0 11.5 8 11 12 3z" fill="currentColor"/></svg>} />
      <Item href="/admin/plugins" label="Plugins" icon={<svg viewBox="0 0 24 24" fill="none" className="w-5 h-5"><path d="M7 2h10v4H7V2zm0 6h10v14H7V8z" fill="currentColor"/></svg>} />
      <Item href="/admin/users" label="Users" icon={<svg viewBox="0 0 24 24" fill="none" className="w-5 h-5"><path d="M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm0 2c-5 0-9 2.5-9 5v2h18v-2c0-2.5-4-5-9-5z" fill="currentColor"/></svg>} />
      <Item href="/admin/tools" label="Tools" icon={<svg viewBox="0 0 24 24" fill="none" className="w-5 h-5"><path d="M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7l3-7z" fill="currentColor"/></svg>} />
      <Item href="/admin/settings" label="Settings" icon={<svg viewBox="0 0 24 24" fill="none" className="w-5 h-5"><path d="M19.4 12.9c.04-.3.06-.6.06-.9s-.02-.6-.06-.9l2.1-1.6a.5.5 0 0 0 .12-.64l-2-3.4a.5.5 0 0 0-.6-.22l-2.5 1a7.1 7.1 0 0 0-1.5-.9l-.4-2.7A.5.5 0 0 0 12 2h-4a.5.5 0 0 0-.5.42l-.4 2.7c-.5.2-.9.5-1.5.9l-2.5-1a.5.5 0 0 0-.6.22l-2 3.4c-.14.23-.09.52.12.64L4.6 11c-.04.3-.06.6-.06.9s.02.6.06.9L2.5 14.4a.5.5 0 0 0-.12.64l2 3.4c.14.23.43.32.66.22l2.5-1c.6.4 1.1.7 1.5.9l.4 2.7c.05.26.27.43.5.43h4c.23 0 .45-.17.5-.43l.4-2.7c.5-.2.9-.5 1.5-.9l2.5 1c.23.1.52.01.66-.22l2-3.4c.14-.23.09-.52-.12-.64L19.4 12.9z" fill="currentColor"/></svg>} />
    </nav>
  )
}
