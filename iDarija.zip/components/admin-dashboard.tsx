"use client"
import React, { useEffect, useState } from 'react'
import Link from 'next/link'
import PostEditor from './post-editor'

type Post = { slug: string; title: string; description?: string; content?: string; image?: string; published?: boolean }
type User = { name: string; email: string }
type Message = { id: string; name: string; email: string; message: string; date: string }
type Testimonial = { id: string; name: string; text: string; rating: number; date: string }

const POSTS_KEY = 'iDarija_posts'
const USERS_KEY = 'iDarija_users'
const MESSAGES_KEY = 'iDarija_messages'
const TESTIM_KEY = 'iDarija_testimonials'
const SEO_KEY = 'iDarija_seo'
const ADMIN_FLAG = 'iDarija_admin'

function safeParse<T>(k: string, fallback: T) {
  try {
    const raw = localStorage.getItem(k)
    if (!raw) return fallback
    return JSON.parse(raw) as T
  } catch (e) {
    return fallback
  }
}

export default function AdminDashboard() {
  const [isAdmin, setIsAdmin] = useState(false)
  const [secret, setSecret] = useState('')

  const [posts, setPosts] = useState<Post[]>([])
  const [editorOpen, setEditorOpen] = useState(false)
  const [editingPost, setEditingPost] = useState<Post | null>(null)
  const [users, setUsers] = useState<User[]>([])
  const [messages, setMessages] = useState<Message[]>([])
  const [testims, setTestims] = useState<Testimonial[]>([])
  const [seo, setSeo] = useState<any>({})

  useEffect(() => {
    try { setIsAdmin(!!localStorage.getItem(ADMIN_FLAG)) } catch (e) {}
    setPosts(safeParse<Post[]>(POSTS_KEY, []))
    setUsers(safeParse<User[]>(USERS_KEY, []))
    setMessages(safeParse<Message[]>(MESSAGES_KEY, []))
    setTestims(safeParse<Testimonial[]>(TESTIM_KEY, []))
    setSeo(safeParse<any>(SEO_KEY, { title: '', description: '' }))
  }, [])

  const save = (key: string, value: any) => {
    try { localStorage.setItem(key, JSON.stringify(value)) } catch (e) {}
  }

  const login = () => {
    // very small local admin check: secret equals 'admin' (changeable)
    if (secret === 'admin') {
      try { localStorage.setItem(ADMIN_FLAG, '1') } catch (e) {}
      setIsAdmin(true)
      setSecret('')
    } else {
      alert('Invalid admin password')
    }
  }

  const logout = () => {
    try { localStorage.removeItem(ADMIN_FLAG) } catch (e) {}
    setIsAdmin(false)
  }

  // Posts management
  const addPost = () => {
    const p: Post = { slug: `post-${Date.now()}`, title: '', description: '', content: '', published: false }
    setEditingPost(p)
    setEditorOpen(true)
  }
  const updatePost = (slug: string, patch: Partial<Post>) => {
    const next = posts.map(p => p.slug === slug ? { ...p, ...patch } : p)
    setPosts(next); save(POSTS_KEY, next)
  }
  const deletePost = (slug: string) => {
    if (!confirm('Delete post?')) return
    const next = posts.filter(p => p.slug !== slug)
    setPosts(next); save(POSTS_KEY, next)
  }

  const openEditor = (post?: Post) => {
    setEditingPost(post ?? null)
    setEditorOpen(true)
  }

  const onSavePost = (post: Post) => {
    const existing = posts.find(p => p.slug === post.slug)
    const merged: Post = { ...post, published: existing?.published || post.published || false }
    const others = posts.filter(p => p.slug !== post.slug)
    const next = [merged, ...others]
    setPosts(next); save(POSTS_KEY, next)
    setEditorOpen(false)
    setEditingPost(null)
  }

  const togglePublish = (slug: string) => {
    const next = posts.map(p => p.slug === slug ? { ...p, published: !p.published } : p)
    setPosts(next); save(POSTS_KEY, next)
  }

  const previewPost = (post: Post) => {
    const w = window.open('', '_blank')
    if (!w) return
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>${post.title}</title></head><body><h1>${post.title}</h1><div>${post.content||''}</div></body></html>`
    w.document.open(); w.document.write(html); w.document.close()
  }

  // Users
  const deleteUser = (email: string) => {
    if (!confirm('Delete user?')) return
    const next = users.filter(u => u.email !== email)
    setUsers(next); save(USERS_KEY, next)
  }

  // Messages
  const deleteMessage = (id: string) => {
    const next = messages.filter(m => m.id !== id)
    setMessages(next); save(MESSAGES_KEY, next)
  }

  // Testimonials
  const deleteTestim = (id: string) => {
    const next = testims.filter(t => t.id !== id)
    setTestims(next); save(TESTIM_KEY, next)
  }

  // SEO
  const saveSeo = () => { save(SEO_KEY, seo); alert('SEO saved') }

  if (!isAdmin) {
    return (
      <div className="max-w-4xl mx-auto p-8">
        <h2 className="text-2xl font-bold mb-4">Admin login</h2>
        <p className="mb-4 text-gray-600">Enter admin password (local demo). Default: <code>admin</code></p>
        <div className="flex gap-2">
          <input value={secret} onChange={(e) => setSecret(e.target.value)} className="border rounded px-3 py-2" placeholder="admin password" />
          <button onClick={login} className="px-3 py-2 bg-primary text-white rounded-md">Login</button>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full max-w-7xl mx-auto p-4">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Dashboard</h1>
      </div>

      {/* Top widgets */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div role="region" aria-label="At a Glance" tabIndex={0} className="bg-white border rounded p-4 focus:outline-none focus:ring-2 focus:ring-primary transition-shadow hover:shadow-lg">
          <h3 className="font-semibold mb-3">At a Glance</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
            <StatCard label="Posts" value={String(posts.length)} />
            <StatCard label="Pages" value="0" />
            <StatCard label="Comments" value={String(messages.length)} />
            <StatCard label="Users" value={String(users.length)} />
          </div>
        </div>

        <div role="region" aria-label="Activity" tabIndex={0} className="bg-white border rounded p-4 md:col-span-2 focus:outline-none focus:ring-2 focus:ring-primary transition-shadow hover:shadow-lg">
          <h3 className="font-semibold mb-3">Activity</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <div className="text-sm text-gray-600 mb-2">Recent messages</div>
              <div className="space-y-2 max-h-56 overflow-auto">
                {messages.slice(0,5).map(m => (
                  <div key={m.id} className="border rounded p-2 hover:bg-gray-50 focus:outline-none focus:ring-1 focus:ring-primary" tabIndex={0}>
                    <div className="flex items-center justify-between">
                      <div className="font-semibold text-sm">{m.name}</div>
                      <div className="text-xs text-gray-400">{new Date(m.date).toLocaleString()}</div>
                    </div>
                    <div className="text-sm text-gray-700">{m.message}</div>
                  </div>
                ))}
                {messages.length===0 && <div className="text-sm text-gray-500">No recent messages.</div>}
              </div>
            </div>

            <div>
              <div className="text-sm text-gray-600 mb-2">Recent feedback</div>
              <div className="space-y-2 max-h-56 overflow-auto">
                {testims.slice(0,5).map(t => (
                  <div key={t.id} className="border rounded p-2 hover:bg-gray-50 focus:outline-none focus:ring-1 focus:ring-primary" tabIndex={0}>
                    <div className="font-semibold text-sm">{t.name} <span className="text-xs text-gray-400">• {new Date(t.date).toLocaleDateString()}</span></div>
                    <div className="text-sm text-gray-700">{t.text}</div>
                  </div>
                ))}
                {testims.length===0 && <div className="text-sm text-gray-500">No feedback yet.</div>}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Draft + Recent Posts */}
      <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white border rounded p-4 lg:col-span-2">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold">Recent Posts</h3>
            <div className="text-sm text-gray-500">Showing latest</div>
          </div>
          <div className="space-y-3 max-h-[52vh] overflow-auto">
            {posts.slice(0,10).map(p => (
              <div key={p.slug} className="border rounded p-3 flex items-center justify-between hover:bg-gray-50 focus:outline-none focus:ring-1 focus:ring-primary" tabIndex={0}>
                <div>
                  <div className="font-semibold">{p.title || <span className="text-gray-400">(Untitled)</span>}</div>
                  <div className="text-xs text-gray-500">{p.description}</div>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => previewPost(p)} className="px-2 py-1 border rounded text-sm">Preview</button>
                  <button onClick={() => openEditor(p)} className="px-2 py-1 bg-primary text-white rounded text-sm">Edit</button>
                </div>
              </div>
            ))}
            {posts.length===0 && <div className="text-sm text-gray-500">No posts yet.</div>}
          </div>
        </div>

        <div className="bg-white border rounded p-4">
          <h3 className="font-semibold mb-3">Quick Draft</h3>
          <QuickDraft onCreate={(title, body)=>{
            const slug = `post-${Date.now()}`
            const post: Post = { slug, title, description: body.slice(0,120), content: `<p>${body}</p>`, published: false }
            const next = [post, ...posts]
            setPosts(next); save(POSTS_KEY, next)
            alert('Draft saved')
          }} />
        </div>
      </div>
      {editorOpen && (
        <div className="fixed inset-0 bg-black/40 flex items-start md:items-center justify-center p-4 z-50">
          <div className="bg-white w-full max-w-4xl rounded shadow-lg overflow-auto max-h-[90vh]">
            <div className="p-3 border-b flex items-center justify-between">
              <div className="font-semibold">{editingPost ? 'Edit Post' : 'New Post'}</div>
              <div>
                <button onClick={()=>{setEditorOpen(false); setEditingPost(null)}} className="px-3 py-1">Close</button>
              </div>
            </div>
            <div className="p-4">
              <PostEditor initial={editingPost ?? undefined} onSave={onSavePost} onCancel={()=>{setEditorOpen(false); setEditingPost(null)}} />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function QuickDraft({ onCreate }: { onCreate: (title: string, body: string)=>void }){
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  return (
    <div>
      <input value={title} onChange={(e)=>setTitle(e.target.value)} placeholder="Title" className="w-full border px-2 py-1 rounded mb-2" />
      <textarea value={body} onChange={(e)=>setBody(e.target.value)} rows={6} className="w-full border px-2 py-1 rounded mb-2" placeholder="Write something..."></textarea>
      <div className="flex justify-end gap-2">
        <button onClick={()=>{ setTitle(''); setBody('') }} className="px-3 py-1 border rounded">Discard</button>
        <button onClick={()=>{ if (!title && !body) return alert('Add title or content'); onCreate(title||'(Untitled)', body); setTitle(''); setBody('') }} className="px-3 py-1 bg-primary text-white rounded">Save Draft</button>
      </div>
    </div>
  )
}

function StatCard({ label, value }: { label: string; value: string }){
  return (
    <div className="p-3 border rounded flex flex-col items-start justify-center hover:shadow-sm transition-all bg-white">
      <div className="text-xs text-gray-500">{label}</div>
      <div className="font-bold text-2xl">{value}</div>
    </div>
  )
}
